/*
 * main.c
 *
 *  Created on: Jan 31, 2024
 *      Author: asemf
 */

#include <avr/interrupt.h>
#include<avr/io.h>



static unsigned char seconds0 = 0;
static unsigned char seconds1 = 0;
static unsigned char minutes0 = 0;
static unsigned char minutes1 = 0;
static unsigned char hours0 = 0;
static unsigned char hours1 = 0;


static void INT0_Init(void);
static void INT1_Init(void);
static void INT2_Init(void);
static void Timer1_Init(void);

int main(void){

	DDRA |= 0x3F;
	DDRC |= 0x0F;

	Timer1_Init();
	INT0_Init();
	INT1_Init();
	INT2_Init();


	while(1)
	{

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (seconds0 & 0x0F);
		PORTA |= (1<<PA0);

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (seconds1 & 0x0F);
		PORTA |= (1<<PA1);

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (minutes0 & 0x0F);
		PORTA |= (1<<PA2);

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (minutes1 & 0x0F);
		PORTA |= (1<<PA3);

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (hours0 & 0x0F);
		PORTA |= (1<<PA4);

		PORTA &= 0xC0;
		PORTC = (PORTC & 0xF0) | (hours1 & 0x0F);
		PORTA |= (1<<PA5);

	}
	return 0;
}


ISR(TIMER1_COMPA_vect)
{

	seconds0++;

	if(seconds0 == 10)
	{
		seconds1++;
		seconds0 = 0;
	}
	if(seconds1 == 6)
	{
		minutes0++;
		seconds1 = 0;
	}
	if(minutes0 == 10)
	{
		minutes1++;
		minutes0 = 0;
	}
	if(minutes1 == 6)
	{
		hours0++;
		minutes1 = 0;
	}
	if(hours0 == 10)
	{
		hours1++;
		hours0 = 0;
	}
}

ISR(INT0_vect)
{
	seconds0 = 0;
	seconds1 = 0;
	minutes0 = 0;
	minutes1 = 0;
	hours0 = 0;
	hours1 = 0;
}

ISR(INT1_vect)
{
	TCCR1B &= ~(1<<CS10);
	TCCR1B &= ~(1<<CS11);
	TCCR1B &= ~(1<<CS12);
}

ISR(INT2_vect)
{
	TCCR1B |= (1<<CS12) | (1<<CS10);
}

static void INT0_Init(void){
	DDRD &= ~(1<<2);
	MCUCR |= (1<<ISC01);
	GICR |= (1<<INT0);
	SREG |= (1<<7);
}

static void INT1_Init(void){
	DDRD &= ~(1<<3);
	MCUCR |= (1<< ISC11);
	MCUCR |= (1<< ISC10);
	GICR |= (1<<INT1);
	SREG |= (1<<7);
}

static void INT2_Init(void){
	DDRB &=~(1<<2);
	MCUCSR |= (1<<ISC2);
	SREG |= (1<<7);
	GICR |= (1<<INT2);
}

static void Timer1_Init(void)
{
	TIMSK |= (1 << OCIE1A);
	TCCR1A = (1 << FOC1A);
	OCR1A = 1000;
	SREG |= (1 << 7);
	TCNT1 = 0;
	TCCR1B = (1 << WGM12) | (1 << CS12) | (1 << CS10);
}


